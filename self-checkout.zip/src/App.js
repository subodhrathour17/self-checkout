import React, { Fragment } from "react";
import AppRoute from "./routes";

const App = () => {
  return (
    <Fragment>
      <AppRoute />
    </Fragment>
  );
};

export default App;
